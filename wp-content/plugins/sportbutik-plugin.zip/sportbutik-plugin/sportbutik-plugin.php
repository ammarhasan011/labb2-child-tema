<?php
/*
Plugin Name: sportbutik plugin
Description: Adds a simple code
*/

function mes()
{
    echo 'hej från plugin';
}

add_action('wp_head', 'mes');
